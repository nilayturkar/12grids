document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('contact-form');
    const formMessage = document.getElementById('form-message');

    form.addEventListener('submit', function(event) {
        event.preventDefault(); // Prevent the default form submission
        let hasError = false;

        // Clear previous error messages
        const errorMessages = form.querySelectorAll('.error-message');
        errorMessages.forEach(message => message.remove());

        // Validate inputs
        const inputs = form.querySelectorAll('input, textarea');
        inputs.forEach(input => {
            if (!input.value.trim()) {
                showError(input, 'This field is required');
                hasError = true;
            } else if (input.type === 'email' && !validateEmail(input.value)) {
                showError(input, 'Please enter a valid email');
                hasError = true;
            } else if (input.name === 'contact' && !validateContact(input.value)) {
                showError(input, 'Please enter a valid 10-digit contact number');
                hasError = true;
            } else if (input.name === 'name' && !validateName(input.value)) {
                showError(input, 'Name should be at least 3 characters long and contain only letters and spaces');
                hasError = true;
            } else if (input.name === 'organization' && !validateOrganization(input.value)) {
                showError(input, 'Organization name should be at least 3 characters long');
                hasError = true;
            } else if (input.name === 'message' && !validateMessage(input.value)) {
                showError(input, 'Message should be at least 10 characters long');
                hasError = true;
            }
        });

        if (!hasError) {
            showSuccess('Form submitted successfully!');
            setTimeout(() => {
                formMessage.style.display = 'none';
            }, 5000);
            form.reset();
        }
    });


    function showError(input, message) {
        const error = document.createElement('div');
        error.className = 'error-message';
        error.textContent = message;
        input.parentElement.appendChild(error);
    }

    function showSuccess(message) {
        formMessage.className = 'form-message success';
        formMessage.textContent = message;
        formMessage.style.display = 'block';
    }

    function validateEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email.toLowerCase());
    }

    function validateContact(contact) {
        const re = /^\d{10}$/;
        return re.test(contact);
    }

    function validateName(name) {
        const re = /^[A-Za-z\s]{3,}$/;
        return re.test(name);
    }

    function validateOrganization(organization) {
        return organization.length >= 3
    }

    function validateMessage(message) {
        return message.length >= 10;
    }

});
